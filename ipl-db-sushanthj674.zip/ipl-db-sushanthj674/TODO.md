# db extension

[] ## match player table
```
match_id (Foreign Key)
player_id (Foreign Key)
team_id (Foreign Key)
```

## innings table
```
inning_id (Primary Key)
match_id (Foreign Key)
team_id (Foreign Key)
total_runs
total_wickets
overs_bowled
```
## Overs Table

```
over_id (Primary Key)
inning_id (Foreign Key)
over_number
bowler_id (Foreign Key)
```
