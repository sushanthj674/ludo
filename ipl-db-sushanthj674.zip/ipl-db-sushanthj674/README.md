# IPL Database Assignment

This assignment involves designing a PostgreSQL database to store IPL match data and writing scripts to populate and query the data.

## Steps to Complete the Assignment

1. **Fetch the Data**

   - Use the `fetch_ipl_data.sh` script to download IPL match data from Cricsheet.

2. **Analyze the Data**

   - Examine the JSON structure to understand the available information.

3. **Design the Schema**

   - Start with the metadata for matches and gradually expand to include other details like deliveries and wickets. Refer to the [guide](guide.md) for further clarity.

4. **Convert Data to CSV**

   - Write scripts to transform JSON data into a CSV format suitable for database insertion.

5. **Populate the Database**

   - Begin by inserting a single match, then gradually expand to multiple matches.
   - Ensure that foreign key relationships are correctly established using subqueries.

6. **Write Queries**

   - Develop SQL queries to retrieve relevant insights from the data.

7. **Test and Validate**
   - Run queries against different datasets to verify correctness and performance.

8. **Include ER Diagram**
   - Please commit an ER Diagram of your schema.
